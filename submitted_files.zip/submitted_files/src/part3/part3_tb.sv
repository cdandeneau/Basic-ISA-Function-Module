module tb_randomize_p2;

// Parameters
localparam int WIDTH = 16;
localparam int INSTR_LEN = 20;
localparam int ADDR = 5;
localparam int PROG_LEN =100;

  logic clk, reset, go;
  logic instruction_done;
  logic [WIDTH-1:0] result;
  logic [WIDTH-1:0] expected = 0;

  // For memory interface
  logic        wr_en;
  logic [ADDR-1:0]  wr_addr;
  logic [INSTR_LEN-1:0] wr_data;

  // Local variables for loops
  int i,j;

// Temporary signals for coverage
  logic [7:0] a_sig, b_sig;
  logic [3:0] opcode_sig;

  // Instantiate DUT
  top  #(.WIDTH(WIDTH),.INSTR_LEN(INSTR_LEN),.ADDR(ADDR),.PROG_LEN(PROG_LEN)) dut (
    .clk(clk),
    .reset(reset),
    .go(go),
    .done(instruction_done),
    .result(result),

    // memory connections
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data)
  );

  // Clock generation
  initial clk = 0;
  always #5 clk = ~clk;



  // ===== CRV Instruction Class =====
  class instr;
    rand bit [3:0] opcode;    // 4-bit opcode
    rand bit [7:0] a, b;      // 8-bit operands

    constraint valid_opcode_c {
    opcode inside {
        4'b0001,
        4'b0010,
        4'b0011,
        4'b1011,
        4'b1111
    };
  }
  constraint operands_c {

    if (opcode == 4'b0001) {
      // ADD: both operands 0 to 50
      a inside {[0:50]};
      b inside {[0:50]};
    }

    else if (opcode == 4'b0010) {
      // SUB: a must be greater than b
      a > b;
    }

    else if (opcode == 4'b0011) {
      // MUL: a even, b odd
      a[0] == 1'b0;
      b[0] == 1'b1;
    }

    else if (opcode == 4'b1011) {
      // GCD: neither operand is zero
      a != 0;
      b != 0;
    }

  }

  constraint opcode_weight_c {
    opcode dist {
        4'b0001 := 70,
        4'b0010 := 70,
        4'b0011 := 15,
        4'b1011 := 5
    };
  }

endclass

  instr instr_obj;

  // --------------------------------------------------
  // Reference Model 
  // --------------------------------------------------
  function automatic bit [WIDTH-1:0] ref_model(input [3:0] opcode, input [7:0] a, input [7:0] b);
    int x = a, y = b;
    case (opcode)
      4'b0001: ref_model = a + b;
      4'b0010: ref_model = a - b;
      4'b0011: ref_model = a * b;
      4'b1011: begin
        while (y != 0) begin
          int temp = y;
          y = x % y;
          x = temp;
        end
        ref_model = x;
      end
      default: ref_model = 16'd0;
    endcase
  endfunction

  // Task to write to memory
  task mem_write(input [ADDR-1:0] addr, input [INSTR_LEN-1:0] data);
    begin
      @(posedge clk);
      go <= 1'b1;
      wr_en   <= 1;
      wr_addr <= addr;
      wr_data <= data;
      @(posedge clk);
      wr_en   <= 0;
      go <= 1'b0;
    end
  endtask

 // =============================
  // Functional Coverage
  // =============================
  covergroup cg_inputs @(posedge clk); // samples at posedge clk
    coverpoint a_sig {
      bins a [] = {[0:255]};
      
    }

    coverpoint b_sig {
      bins b [] = {[0:255]};
      
    }
    coverpoint opcode_sig {
      bins valid_opcode = {4'b0001, 4'b0010, 4'b0011, 4'b1011, 4'b1111};
       bins invalid_opcode = {4'b0000, 4'b0100, 4'b0101, 4'b0110, 4'b0111, 4'b1000, 4'b1001, 4'b1010, 4'b1100, 4'b1101, 4'b1110};
    }
  

  endgroup

  cg_inputs cov_inst = new();

  
   
    
  // Test Sequence
  initial begin
    wr_en   <= 0; 
    wr_addr <= 0; 
    wr_data <= 0;
    reset   <= 1;
    go <= 0;
    #20 reset <= 0;

    $display("=== Starting CRV Testbench ===");
    
    // object creation
    instr_obj = new();

    //Randomization
     for (int i = 0; i < PROG_LEN; i++) begin
      // Randomize the object
      assert(instr_obj.randomize())
        else begin
          $error("Randomization failed!");
          $finish;
        end

	 // Assign to signals for coverage
      a_sig = instr_obj.a;
      b_sig = instr_obj.b;
      opcode_sig = instr_obj.opcode;

	// cov_inst.sample(); if want to explicitly sample; but not necessary here
                           // because we sample at posedge clk

      // Show generated values to students
      $display("Displaying Memory Contents Iter=%0d | Opcode=%04b | A=%0d | B=%0d", 
                i, instr_obj.opcode, instr_obj.a, instr_obj.b);

      // Write randomized instruction to memory
      mem_write(i, {instr_obj.opcode, instr_obj.a, instr_obj.b});

      // Wait for DUT to complete
      @(posedge clk)
      wait(instruction_done);  

      expected = ref_model(instr_obj.opcode, instr_obj.a, instr_obj.b);

      //Comparison expected with Dut Result
      if (result !== expected) begin
        $error("FAIL | Opcode=%04b A=%0d B=%0d | Got=%0d, Expected=%0d",
                instr_obj.opcode, instr_obj.a, instr_obj.b, result, expected);
      end else begin
        $display("Result_PASS | Opcode=%04b A=%0d B=%0d | Result=%0d",
                 instr_obj.opcode, instr_obj.a, instr_obj.b, result);

                  $display(".............................");
      end
    end

    #10;
    $display("=== Test Finished ===");
    $finish;
  end


endmodule
